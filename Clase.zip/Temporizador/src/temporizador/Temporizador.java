/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temporizador;

import java.io.Serializable;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JLabel;

/**
 *
 * @author alumnop
 */
public class Temporizador extends JLabel implements Serializable {

    private int segundos;
    private String finalizar = "FIN";

    public Temporizador() {
    }

    public int getSegundos() {
        return segundos;
    }

    public void setSegundos(int segundos) {
        this.segundos = segundos;
    }

    public String getFinalizar() {
        return finalizar;
    }

    public void setFinalizar(String finalizar) {
        this.finalizar = finalizar;
    }
    
    

    public void start() {

        setText("" + segundos);
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                setText("" + segundos--);
                if (segundos < 0) {
                    setText(finalizar);
                    cancel();
                }
            }
        }, 0, 1000);

    }

}
